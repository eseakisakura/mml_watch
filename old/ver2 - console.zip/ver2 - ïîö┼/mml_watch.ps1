<# mml_watch.ps1 ������ #> 

function nsf_trans([string]$p){

	if($Args_path[3] -eq $true){	# chk_ppmck

		.\mck_script\mknsf.ps1 $p | Write-Host
	}else{

		& $exe_nsc -n -e $file_mml | Write-Host	# &Command
	}

	Write-Host ("`r`n"+ "exitcode: "+ $LASTEXITCODE)

	if($LASTEXITCODE -ne 0){

		Write-Host ("`r`n"+ "NSFfile: failure !")
		Write-Host ("watches: "+ $Args_path[2])
		return -1
	}else{

		$c= Start-Process -PassThru $exe_player $file_nsf

		Write-Host ("`r`n"+ "PID: "+ $c.Id)	#�v���Z�XID�擾
		Write-Host ("watches: "+ $Args_path[2])
		return $c
	}
} #func


[array]$Args_path= $Args

[string]$exe_nsc= "..\bin\nsc.exe"
[string]$file_mml= "`""+ $Args_path[0]+ ".mml`""	# esc[`"]

[string]$exe_player= $Env:exe_ply
[string]$file_nsf= "`""+ $Args_path[0]+ ".nsf`""


$chk_ps= nsf_trans $Args_path[0]


$w= New-Object System.IO.FileSystemWatcher
$w.Path= $Args_path[1]
$w.Filter= $Args_path[2]
$w.NotifyFilter= [System.IO.NotifyFilters]::LastWrite

$ErrorActionPreference = "Stop"
try{

while(1){
	sleep -m 2048	#�ُ펞�p�E�F�C�g
	$r= $w.WaitForChanged([System.IO.WatcherChangeTypes]::Changed)

	if($chk_ps -ne -1){	#���폈���`�F�b�N
		if($chk_ps.hasexited -ne $true){	#PID��ԃ`�F�b�N

			Write-Host ("kill--PID: "+ $chk_ps.Id)
			kill $chk_ps.Id
		}
	}
	Write-Host ("updated: "+ $r.ChangeType+ "`r`n")

	$chk_ps= nsf_trans $Args_path[0]
} #

}
catch [Exception]{	#err_all
	echo $_.exception
	Read-Host "������ɂ�ENTER�������ĉ�����" | Out-Null
}
 

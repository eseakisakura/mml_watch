<# mml_watch.ps1 ������ #> 

function nsf_trans([string]$p){

	if((Test-Path .\mck_script\mknsf.ps1) -eq $true){	# chk_ppmck

		.\mck_script\mknsf.ps1 $p | Write-Host
	}else{
		& $exe_nsc -n -e $file_mml | Write-Host		# &Command
	}

	Write-Host ("`r`n"+ "exitcode: "+ $LASTEXITCODE)

	if($LASTEXITCODE -ne 0){

		Write-Host ("`r`n"+ "NSF file: failure !")
		Read-Host "������ɂ�ENTER�������ĉ�����" | Out-Null
		exit
	}else{
		& $exe_player /play $file_nsf			# �Đ�
		Write-Host ("watches: "+ $Args_path[2])

		sleep -m 2048	#�ُ펞�p�E�F�C�g
	}
} #func


[array]$Args_path= $Args

[string]$exe_nsc= "..\bin\nsc.exe"
[string]$file_mml= "`""+ $Args_path[0]+ ".mml`""	# esc[`"]

[string]$exe_player= $Env:exe_ply
[string]$file_nsf= "`""+ $Args_path[0]+ ".nsf`""


nsf_trans($Args_path[0])

$w= New-Object System.IO.FileSystemWatcher
$w.Path= $Args_path[1]
$w.Filter= $Args_path[2]
$w.NotifyFilter= [System.IO.NotifyFilters]::LastWrite

$ErrorActionPreference = "Stop"
try{

while(1){
	$r= $w.WaitForChanged([System.IO.WatcherChangeTypes]::Changed)

	& $exe_player /STOP				# ��~

	Write-Host ("updated: "+ $r.ChangeType+ "`r`n")
	nsf_trans($Args_path[0])
} #
}
catch [Exception]{	#err_all
	echo $_.exception
	Read-Host "������ɂ�ENTER�������ĉ�����" | Out-Null
}

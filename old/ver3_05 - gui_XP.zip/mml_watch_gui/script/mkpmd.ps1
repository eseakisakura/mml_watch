﻿<# mkpmd.ps1 #> 

[string[]]$r= $Args	# mml,bin,dmc,option

[string[]]$arr= .\split_path.ps1 $r[1]
[string]$exe_mc= '.\'+ $arr[0]


if($exe_mc -ne '.\mc.exe'){	# compiler chk

	Write-Host ("`r`n"+ '"mkpmd.ps1">> mc.exeが見つかりません')
	$LASTEXITCODE= 3


}elseif((Test-Path $r[1]) -eq $false){	# compiler path chk

	Write-Host ("`r`n"+ '"mkpmd.ps1">> '+ $exe_mc+ 'がパス上にありません')
	$LASTEXITCODE= 2


}else{
	switch($r[3]){
		'opn'{   [string]$opt= '/n' }
		'opl'{   [string]$opt= '/l' }
		'opm'{   [string]$opt= '/m' }
		'towns'{ [string]$opt= '/t' }
	} #sw


	[string]$Env:PMD= $r[2]	# パス対応素でよし
	[string[]]$ary= .\split_path.ps1 $r[0]


	pushd $arr[1]

	copy -force -literalpath ($r[0]+ '.mml') -destination '.\tmp.mml'
	# onaji karento denaito error


	& $exe_mc /v $opt 'tmp.mml' | Write-Host	# Command時、[&]必要
	# ".\tmp.mml" deha error
	sleep -m 240


	if($LASTEXITCODE -eq 0){

		move -force -literalpath '.\tmp.m' -destination ((Join-Path $ary[1] $ary[2])+ '.m')

		if((Test-Path '.\tmp.mml') -eq $true){ del '.\tmp.mml' }
	}


	popd	# mml_watchへ
}

exit $LASTEXITCODE
 

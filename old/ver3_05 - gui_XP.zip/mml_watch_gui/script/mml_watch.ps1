﻿<# mml_watch.ps1 GUI版 #> 

Write-Host ("`"mml_watch`"を起動します")
 
$xml_string= @' 
<table>
	<!-- status / nameは固定値 -->
	<value name= "mmlfile" param= ""/>
	<value name= "compiler" param= "..\nsdlib\bin\nsc.exe"/>
	<value name= "player" param= "..\nsfplay\nsfplay.exe"/>
	<value name= "dmcdir" param= ""/>
	<value name= "editor" param= ""/>
	<br />
	<box name= "option" param= "opn"/>
	<box name= "radio_bin" param= "nsd"/>
	<box name= "chk_stop" param= "Checked"/>
	<box name= "chk_topmost" param= "true"/>
	<br />

	<!-- listbox / nameは変動値 -->
	<mml name= "" param= ""/>
	<mml name= "" param= ""/>
	<mml name= "" param= ""/>
	<mml name= "" param= ""/>
	<br />
	<mck name= "ppmckc.exe" param= "..\ppmck\bin\ppmckc.exe"/>
	<mck name= "" param= ""/>
	<mck name= "" param= ""/>
	<mck name= "" param= ""/>
	<br />
	<nsd name= "nsc.exe" param= "..\nsdlib\bin\nsc.exe"/>
	<nsd name= "" param= ""/>
	<nsd name= "" param= ""/>
	<nsd name= "" param= ""/>
	<br />
	<pmd name= "mc.exe" param= "..\pmd\mc.exe"/>
	<pmd name= "" param= ""/>
	<pmd name= "" param= ""/>
	<pmd name= "" param= ""/>
	<br />
	<ply name= "nsfplay.exe" param= "..\nsfplay\nsfplay.exe"/>
	<ply name= "winamp.exe" param= "..\winamp\winamp.exe"/>
	<ply name= "FMPMD.exe" param= "..\fmpmd\FMPMD.exe"/>
	<ply name= "" param= ""/>
	<br />
	<dmc name= "" param= ""/>
	<dmc name= "" param= ""/>
	<dmc name= "" param= ""/>
	<dmc name= "" param= ""/>
	<br />
	<edt name= "" param= ""/>
	<edt name= "" param= ""/>
	<edt name= "" param= ""/>
	<edt name= "" param= ""/>
</table>
'@
 
# nsf_trans 
	
function player_stop(){ 


	if($box["chk_stop"] -eq "Checked"){

		& $value["player"] /stop
	}
} #func

 
function mck_trans([string]$file){ 

	[string[]]$arr= .\split_path.ps1 $file
	[string]$dpn= Join-Path $arr[1] $arr[2]


	player_stop

	Write-Host "`r`n"

	# mml,bin,dmc
	.\mkmck.ps1 $dpn $value["compiler"] $value["dmcdir"]
	sleep -m 120

	# $LASTEXITCODE [0-3]
	Write-Host ("`r`n"+ 'exitcode: '+ $LASTEXITCODE)


	if($LASTEXITCODE -ne 0){


		Write-Host ("`r`n"+ 'ERROR!: '+ $arr[0]+ '>> '+ $arr[2]+ '.nsf')
	}else{

		& $value["player"] ('"'+ $dpn+ '.nsf"')
	}
} #func
 
function nsd_trans([string]$file){ 

	[string[]]$arr= .\split_path.ps1 $file
	[string]$dpn= Join-Path $arr[1] $arr[2]


	player_stop

	Write-Host "`r`n"  # 改行

	# mml,bin,dmc
	.\mknsd.ps1 $dpn $value["compiler"] $value["dmcdir"]
	sleep -m 120	# 異常時用ウェイト

	# $LASTEXITCODE [0-3]
	Write-Host ("`r`n"+ 'exitcode: '+ $LASTEXITCODE)


	if($LASTEXITCODE -ne 0){


		Write-Host ("`r`n"+ 'ERROR!: '+ $arr[0]+ '>> '+ $arr[2]+ '.nsf')
	}else{
		# '"' 空白パス対応
		& $value["player"] ('"'+ $dpn+ '.nsf"')
	}
} #func
 
function pmd_trans([string]$file){ 

	[string[]]$arr= .\split_path.ps1 $file
	[string]$dpn= Join-Path $arr[1] $arr[2]


	# player_stop # pmd deha fuyou

	Write-Host "`r`n"

	# mml,bin,dmc
	.\mkpmd.ps1 $dpn $value["compiler"] $value["dmcdir"] $box["option"]
	sleep -m 120

	# $LASTEXITCODE [0-3]
	Write-Host ("`r`n"+ 'exitcode: '+ $LASTEXITCODE)


	if($LASTEXITCODE -ne 0){


		Write-Host ("`r`n"+ 'ERROR!: '+ $arr[0]+ '>> '+ $arr[2]+ '.m')
	}else{

		& $value["player"] ('"'+ $dpn+ '.m"')
	}
} #func
 
function play_nsf([int]$sw,[string]$file){ 


	switch($sw){

	1{
		Write-Host ("`r`n"+ 'Watches: '+ $file)
		break;
	}0{
		[int]$err= chk_path "play_nsf" $file # err msg


		if($err -eq 0){

			switch($box["radio_bin"]){

			'mck'{
				mck_trans $file
				break;
			}'nsd'{
				nsd_trans $file
				break;
			}'pmd'{
				pmd_trans $file

			}
			} #sw
		}
	}
	} #sw
} #func
  
# chk_path 
	
<#Function split_path([string]$file){  # pathがないと通らない 


	[string]$f= [IO.Path]::GetFileName($file)
	[string]$p= [IO.Path]::GetDirectoryName($file)
	[string]$n= [IO.Path]::GetFileNameWithoutExtension($file)
	[string]$x= [IO.Path]::GetExtension($file)

	echo $f
	echo $p
	echo $n
	echo $x  # .mml dot ari
	#return

} #func
#>
 
Function chk_path([string]$ins, [string]$file){ 

	if($file -eq ""){

		if($ins -ne "cancel"){ Write-Host ($ins+ ': Null ERROR') }
		return 2

	}elseif((Test-Path $file) -eq $false){

		if($ins -ne "cancel"){ Write-Host ($ins+ ': FilePath ERROR') }
		return 1

	}else{
		return 0
	}
} #func
 
function console_out([string]$sw,[string]$chk){ 


	[int]$err= chk_path "cancel" $chk

	$rot= @{}
	switch($err){

	2{
		$rot["mml"]= '   mml ファイル 選択されてません> '
		$rot["bin"]= '   exe ファイル 選択されてません> '
		$rot["ply"]= 'player ファイル 選択されてません> '
		$rot["dmc"]= 'includeフォルダ 選択されてません> '

		break;
	}1{
		$rot["mml"]= '   mml ファイル パス先がありません> '
		$rot["bin"]= '   exe ファイル パス先がありません> '
		$rot["ply"]= 'player ファイル パス先がありません> '
		$rot["dmc"]= 'includeフォルダ パス先がありません> '

		break;
	}0{
		$rot["mml"]= '   mml ファイル <'
		$rot["bin"]= '   exe ファイル <'
		$rot["ply"]= 'player ファイル <'
		$rot["dmc"]= 'includeフォルダ <'
	}
	} #sw

	write-host ($rot[$sw]+ $chk)
	return $err

} #func
 
function status_cheker(){ 


	[string]$m= "" # 空値必要、定義のみだと返値(echo)が出る
	[string]$c= ""
	[array]$arr= 0,0,0,0


	Write-Host '' # 改行

	switch($box["radio_bin"]){

		'mck'{ $m= '"ppmck"' } # esc["`""] -> ['"']
		'nsd'{ $m= '"NSDlib"'}
		'pmd'{ $m= '"P.M.D"' }
	} #sw

	if($box["chk_stop"] -eq "Checked"){

		$c= " /stopコマンド付"
	}
	else{}


	Write-Host ('[ '+ $m+ 'モード ] '+ $c)

	Write-Host '' # 改行


	$arr[0]= console_out "mml" $value["mmlfile"]
	$arr[1]= console_out "bin" $value["compiler"]
	$arr[2]= console_out "ply" $value["player"]
	$arr[3]= console_out "dmc" $value["dmcdir"]

	return $arr

} #func
 
function wait_setpath([int[]]$r){ 


	[int]$err= 0
	[int]$stus= $r[0]+ $r[1]+ $r[2]


	Write-Host '' # 改行

	if($stus -ne 0){ # 起動できない回避

		Write-Host ('監視環境が不足 ERR Number>> '+ $r[0]+ ','+ $r[1]+ ','+ $r[2])
		$err= 1

	}else{
		[string[]]$f= .\split_path.ps1 $value["mmlfile"]

		switch($f[3]){

		'.mml'{
			Write-Host ('.mmlの監視をセット <<'+ $f[0])
			break;

		}'.nsf'{
			Write-Host ('.nsfの監視は不可です>> '+ $f[0])
			$err= 1; break;

		}'.m'{
			Write-Host ('.mの監視は不可です>> '+ $f[0])
			$err= 1; break;

		}default{
			Write-Host ('監視対象は、mmlファイルのみ>> '+ $f[0])
			$err= 1
		}
		} #sw
	}


	switch($err){

	0{
		$wait.Path= $f[1]	# RaisingEvents= $true時、必要
		$wait.Filter= $f[0]

		return $true
	}
	1{
		# $wait.Path= $null  # Pathエラーになる
		$wait.Filter= $null

		return $false
	}
	} #sw
} #func
 
function toggle_sw([int]$num,[string]$c){ 

if($num -eq 1){ # w_console out cancel

	switch($c){

	'true'{
		if($wait.EnableRaisingEvents -ne $true){  $num= 0 }
	}
	'false'{
		if($wait.EnableRaisingEvents -ne $false){ $num= 0 }
	}
	} #sw
}

if($num -eq 0){

	switch($c){

	'true'{
		$wait_lbl.Text= "WATCHES"
		$wait_btn.Text= "Pause"
		$wait.EnableRaisingEvents= $true # 開始
		Write-Host ('RaisingEvents: '+ $wait.EnableRaisingEvents)
	}
	'false'{
		$wait_lbl.Text= "STOP"
		$wait_btn.Text= "Restart"
		$wait.EnableRaisingEvents= $false
		Write-Host ('RaisingEvents: '+ $wait.EnableRaisingEvents)
	}
	} #sw
}
} #func
  
# hash 
	
function xml_read($x){ 


for([int]$i=4; $i -ge 0; $i--){


	if($x.value[$i].name -ne ""){

		$value[$x.value[$i].name]= $x.value[$i].param
	}


	if($i -lt 4){

		if($x.box[$i].name -ne ""){

			$box[$x.box[$i].name]= $x.box[$i].param
		}
		if($x.mml[$i].name -ne ""){

			$mml[$x.mml[$i].name]= $x.mml[$i].param
		}

		if($x.mck[$i].name -ne ""){

			$mck[$x.mck[$i].name]= $x.mck[$i].param
		}
		if($x.nsd[$i].name -ne ""){

			$nsd[$x.nsd[$i].name]= $x.nsd[$i].param
		}
		if($x.pmd[$i].name -ne ""){

			$pmd[$x.pmd[$i].name]= $x.pmd[$i].param
		}

		if($x.ply[$i].name -ne ""){

			$ply[$x.ply[$i].name]= $x.ply[$i].param
		}
		if($x.dmc[$i].name -ne ""){

			$dmc[$x.dmc[$i].name]= $x.dmc[$i].param
		}
		if($x.edt[$i].name -ne ""){

			$edt[$x.edt[$i].name]= $x.edt[$i].param
		}
	}

} #

} #func
 
function write_xml($x){ 


	[array]$value_keys= $value.Keys
	[array]$box_keys= $box.Keys
	[array]$mml_keys= $mml.Keys

	[array]$mck_keys= $mck.Keys
	[array]$nsd_keys= $nsd.Keys
	[array]$pmd_keys= $pmd.Keys

	[array]$ply_keys= $ply.Keys
	[array]$dmc_keys= $dmc.Keys
	[array]$edt_keys= $edt.Keys


	[int]$vl= $value_keys.Length
	[int]$bx= $box_keys.Length
	[int]$ml= $mml_keys.Length

	[int]$mk= $mck_keys.Length
	[int]$nd= $nsd_keys.Length
	[int]$pd= $pmd_keys.Length

	[int]$py= $ply_keys.Length
	[int]$dc= $dmc_keys.Length
	[int]$et= $edt_keys.Length


	if($vl -gt 5){ Write-Host ('value hash ERROR >> '+ $vl) }
	if($bx -gt 4){ Write-Host ('box hash ERROR >> '+ $bx) }
	if($ml -gt 4){ Write-Host ('mml hash ERROR >> '+ $ml) }

	if($mk -gt 4){ Write-Host ('mck hash ERROR >> '+ $mk) }
	if($nd -gt 4){ Write-Host ('nsd hash ERROR >> '+ $nd) }
	if($pd -gt 4){ Write-Host ('pmd hash ERROR >> '+ $pd) }

	if($py -gt 4){ Write-Host ('ply hash ERROR >> '+ $py) }
	if($dc -gt 4){ Write-Host ('dmc hash ERROR >> '+ $dc) }
	if($et -gt 4){ Write-Host ('edt hash ERROR >> '+ $et) }


	for([int]$i=4; $i -ge 0; $i--){


		if($i -lt $vl){

			$x.value[$i].name=  [string]$value_keys[$i] # $xmlは[string]キャスト必要
			$x.value[$i].param= [string]$value[$value_keys[$i]]
		}else{
			$x.value[$i].name=  "" # 空を打つ
			$x.value[$i].param= ""
		}


	if($i -lt 4){

		if($i -lt $bx){

			$x.box[$i].name=  [string]$box_keys[$i]
			$x.box[$i].param= [string]$box[$box_keys[$i]]
		}else{
			$x.box[$i].name=  ""
			$x.box[$i].param= ""
		}
		if($i -lt $ml){

			$x.mml[$i].name=  [string]$mml_keys[$i]
			$x.mml[$i].param= [string]$mml[$mml_keys[$i]]
		}else{
			$x.mml[$i].name=  ""
			$x.mml[$i].param= ""
		}

		if($i -lt $mk){

			$x.mck[$i].name=  [string]$mck_keys[$i]
			$x.mck[$i].param= [string]$mck[$mck_keys[$i]]
		}else{
			$x.mck[$i].name=  ""
			$x.mck[$i].param= ""
		}
		if($i -lt $nd){

			$x.nsd[$i].name=  [string]$nsd_keys[$i]
			$x.nsd[$i].param= [string]$nsd[$nsd_keys[$i]]
		}else{
			$x.nsd[$i].name=  ""
			$x.nsd[$i].param= ""
		}
		if($i -lt $pd){

			$x.pmd[$i].name=  [string]$pmd_keys[$i]
			$x.pmd[$i].param= [string]$pmd[$pmd_keys[$i]]
		}else{
			$x.pmd[$i].name=  ""
			$x.pmd[$i].param= ""
		}

		if($i -lt $py){

			$x.ply[$i].name=  [string]$ply_keys[$i]
			$x.ply[$i].param= [string]$ply[$ply_keys[$i]]
		}else{
			$x.ply[$i].name=  ""
			$x.ply[$i].param= ""
		}
		if($i -lt $dc){

			$x.dmc[$i].name=  [string]$dmc_keys[$i]
			$x.dmc[$i].param= [string]$dmc[$dmc_keys[$i]]
		}else{
			$x.dmc[$i].name=  ""
			$x.dmc[$i].param= ""
		}
		if($i -lt $et){

			$x.edt[$i].name=  [string]$edt_keys[$i]
			$x.edt[$i].param= [string]$edt[$edt_keys[$i]]
		}else{
			$x.edt[$i].name=  ""
			$x.edt[$i].param= ""
		}
	}

	} #

} #func
 
function pmd_option(){ 

	switch($box["option"]){


	'opn'{
		$sub_menu_opn.Text= "v OPN 4op"
		$sub_menu_opl.Text= "OPL 2op"
		$sub_menu_opm.Text= "OPM 4op"
		$sub_menu_towns.Text= "TOWNS 4op"
	}
	'opl'{
		$sub_menu_opn.Text= "OPN 4op"
		$sub_menu_opl.Text= "v OPL 2op"
		$sub_menu_opm.Text= "OPM 4op"
		$sub_menu_towns.Text= "TOWNS 4op"
	}
	'opm'{
		$sub_menu_opn.Text= "OPN 4op"
		$sub_menu_opl.Text= "OPL 2op"
		$sub_menu_opm.Text= "v OPM 4op"
		$sub_menu_towns.Text= "TOWNS 4op"
	}
	'towns'{
		$sub_menu_opn.Text= "OPN 4op"
		$sub_menu_opl.Text= "OPL 2op"
		$sub_menu_opm.Text= "OPM 4op"
		$sub_menu_towns.Text= "v TOWNS 4op"
	}
	} #sw
} #func
 
function top_most([string]$c){ 

	$box["chk_topmost"]= $c


	switch($c){

	'true'{

		$sub_f.TopMost= $true # 最前面表示のプロパティ
		$frm.TopMost= $true

		$menu_t.Text= "v 最前面表示"
	}
	'false'{

		$sub_f.TopMost= $false
		$frm.TopMost= $false

		$menu_t.Text= "最前面表示"
	}
	} #sw
} #func
 
function drag_drop([string]$sw,[array]$drp){ 

foreach($i in $drp){


	[int]$err= chk_path $sw $i


	if($err -eq 0){

		[string[]]$f= .\split_path.ps1 $i

		switch($sw){

		'mml'{
			foreach($key in $mml.Keys){ # あらば差替え

				if($f[0] -eq $key){

					if($mml[$f[0]] -ne $i){ # たがえばhash値差替え

				 		$mml[$f[0]]= $i
					}

					$listbox_mml.SelectedItem= $f[0]
				}
			} #

			if($listbox_mml.SelectedItem -ne $f[0]){  # なければハッシュ追加

				if(($mml.Count+1) -le 4){

				 	$mml[$f[0]]= $i
					[void]$listbox_mml.Items.Add($f[0]) # ファイル追加

				}else{

					Write-Host 'mml Slot CountOver'
				}
			}

			break;

		}'mck'{
			foreach($key in $mck.Keys){

				if($f[0] -eq $key){

					if($mck[$f[0]] -ne $i){

				 		$mck[$f[0]]= $i
					}

					$listbox_mck.SelectedItem= $f[0]
				}
			} #

			if($listbox_mck.SelectedItem -ne $f[0]){

				if(($mck.Count+1) -le 4){

				 	$mck[$f[0]]= $i
					[void]$listbox_mck.Items.Add($f[0])

				}else{

					Write-Host 'mck Slot CountOver'
				}
			}

			break;

		}'nsd'{
			foreach($key in $nsd.Keys){

				if($f[0] -eq $key){

					if($nsd[$f[0]] -ne $i){

				 		$nsd[$f[0]]= $i
					}

					$listbox_nsd.SelectedItem= $f[0]
				}
			} #

			if($listbox_nsd.SelectedItem -ne $f[0]){

				if(($nsd.Count+1) -le 4){

				 	$nsd[$f[0]]= $i
					[void]$listbox_nsd.Items.Add($f[0])

				}else{

					Write-Host 'nsd Slot CountOver'
				}
			}

			break;

		}'pmd'{
			foreach($key in $pmd.Keys){

				if($f[0] -eq $key){

					if($pmd[$f[0]] -ne $i){

				 		$pmd[$f[0]]= $i
					}

					$listbox_pmd.SelectedItem= $f[0]
				}
			} #

			if($listbox_pmd.SelectedItem -ne $f[0]){

				if(($pmd.Count+1) -le 4){

				 	$pmd[$f[0]]= $i
					[void]$listbox_pmd.Items.Add($f[0])

				}else{

					Write-Host 'pmd Slot CountOver'
				}
			}

			break;

		}'ply'{
			foreach($key in $ply.Keys){

				if($f[0] -eq $key){

					if($ply[$f[0]] -ne $i){

				 		$ply[$f[0]]= $i
					}

					$listbox_ply.SelectedItem= $f[0]
				}
			} #

			if($listbox_ply.SelectedItem -ne $f[0]){

				if(($ply.Count+1) -le 4){

				 	$ply[$f[0]]= $i
					[void]$listbox_ply.Items.Add($f[0])

				}else{

					Write-Host 'ply Slot CountOver'
				}
			}

			break;

		}'dmc'{
			foreach($key in $dmc.Keys){

				if($f[0] -eq $key){

					if($dmc[$f[0]] -ne $i){

				 		$dmc[$f[0]]= $i
					}

					$listbox_dmc.SelectedItem= $f[0]
				}
			} #

			if($listbox_dmc.SelectedItem -ne $f[0]){

				if(($dmc.Count+1) -le 4){

				 	$dmc[$f[0]]= $i
					[void]$listbox_dmc.Items.Add($f[0])

				}else{

					Write-Host 'dmc Slot CountOver'
				}
			}

			break;

		}'edt'{
			foreach($key in $edt.Keys){

				if($f[0] -eq $key){

					if($edt[$f[0]] -ne $i){

				 		$edt[$f[0]]= $i
					}

					$listbox_edt.SelectedItem= $f[0]
				}
			} #

			if($listbox_edt.SelectedItem -ne $f[0]){

				if(($edt.Count+1) -le 4){

				 	$edt[$f[0]]= $i
					[void]$listbox_edt.Items.Add($f[0])

				}else{

					Write-Host 'edt Slot CountOver'
				}
			}
		}
		} #sw
	}
} #

} #func
 
function editor_open([string]$box,[string]$chk){ 


	[int]$exe_err= chk_path "cancel" $box
	[int]$file_err= chk_path "cancel" $chk

	switch($exe_err){

	2{  Write-Host ('エディタハイライト選択されてません> '+ $box)  }
	1{  Write-Host ('エディタ選択先がありません> '+ $box)  }
	#0{}

	} #sw

	switch($file_err){

	2{  Write-Host ('ファイルハイライト選択されてません> '+ $chk)  }
	1{  Write-Host ('ファイルパス選択先がありません> '+ $chk)  }
	#0{}

	} #sw

	if($exe_err -eq 0){

		if($file_err -eq 0){

			& $box $chk
		}
	}
} #func
 
function folder_open([int]$num,[string]$chk){ 

	switch($num){

	1{
		[int]$err= chk_path "cancel" $chk

		if($err -ne 2){ # stopper

			[string[]]$arr= .\split_path.ps1 $chk # folder path split

			$chk= $arr[1]
		}
	}
	#0{}

	} #sw


	[int]$err= chk_path "cancel" $chk

	switch($err){

	2{  Write-Host ('ハイライト選択されてません > '+ $chk)  }
	1{  Write-Host ('ハイライト先ありません > '+ $chk)  }
	0{  Invoke-Item $chk  } # folder,file open

	} #sw
} #func
 
function hash_read_all(){ 


	pmd_option

	$stop_box.CheckState= $box["chk_stop"]


	$listbox_mml.Items.Clear() # 二重読込対策
	$listbox_mck.Items.Clear()
	$listbox_nsd.Items.Clear()
	$listbox_pmd.Items.Clear()
	$listbox_ply.Items.Clear()
	$listbox_dmc.Items.Clear()
	$listbox_edt.Items.Clear()

	[void]$listbox_mml.Items.AddRange(@($mml.Keys)) # .Addが 戻値あるメソッドため
	[void]$listbox_mck.Items.AddRange(@($mck.Keys))
	[void]$listbox_nsd.Items.AddRange(@($nsd.Keys))
	[void]$listbox_pmd.Items.AddRange(@($pmd.Keys))
	[void]$listbox_ply.Items.AddRange(@($ply.Keys))
	[void]$listbox_dmc.Items.AddRange(@($dmc.Keys))
	[void]$listbox_edt.Items.AddRange(@($edt.Keys))

	$listbox_mck.Hide()
	$listbox_nsd.Hide()
	$listbox_pmd.Hide()


	switch($box["radio_bin"]){

	'mck'{
		$radio_mck.Checked= "True"
		$listbox_mck.Show()

		foreach($key in $mck.Keys){

			if($mck[$key]  -eq $value["compiler"]){ $listbox_mck.SelectedItem= $key }
		} #

		break;
	}'nsd'{
		$radio_nsd.Checked= "True"
		$listbox_nsd.Show()

		foreach($key in $nsd.Keys){

			if($nsd[$key]  -eq $value["compiler"]){ $listbox_nsd.SelectedItem= $key }
		} #

		break;
	}'pmd'{
		$radio_pmd.Checked= "True"
		$listbox_pmd.Show()

		foreach($key in $pmd.Keys){

			if($pmd[$key]  -eq $value["compiler"]){ $listbox_pmd.SelectedItem= $key }
		} #
	}
	} #sw


	foreach($key in $mml.Keys){ # あればハイライト表示

		if($value["mmlfile"] -eq $mml[$key]){ $listbox_mml.SelectedItem= $key }
	} #
	foreach($key in $ply.Keys){

		if($value["player"]  -eq $ply[$key]){ $listbox_ply.SelectedItem= $key }
	} #
	foreach($key in $dmc.Keys){

		if($value["dmcdir"]  -eq $dmc[$key]){ $listbox_dmc.SelectedItem= $key }
	} #
	foreach($key in $edt.Keys){

		if($value["editor"]  -eq $edt[$key]){ $listbox_edt.SelectedItem= $key }
	} #

} #func
 
function write_value(){ 


	$box["chk_stop"]= [string]$stop_box.CheckState


	if([string]$radio_mck.Checked -eq "True"){

		$box["radio_bin"]= "mck"

		if($mck.Count -eq 1){

			$value["compiler"]= $mck.Values
		}else{
			$value["compiler"]= $mck[[string]$listbox_mck.SelectedItem]
		}

	}elseif([string]$radio_nsd.Checked -eq "True"){

		$box["radio_bin"]= "nsd"

		if($nsd.Count -eq 1){

			$value["compiler"]= $nsd.Values
		}else{
			$value["compiler"]= $nsd[[string]$listbox_nsd.SelectedItem]
		}

	}elseif([string]$radio_pmd.Checked -eq "True"){

		$box["radio_bin"]= "pmd"

		if($pmd.Count -eq 1){

			$value["compiler"]= $pmd.Values
		}else{
			$value["compiler"]= $pmd[[string]$listbox_pmd.SelectedItem]
		}
	}


	if($listbox_mml.SelectedItem -eq $null){

		switch($mml.Count){

		0{
			$value["mmlfile"]= $null
		}
		1{
			$value["mmlfile"]= $mml.Values
		}
		default{

			foreach($key in $mml.Values){

				if($key -eq $value["mmlfile"]){ # 意味あって外されてる

					$value["mmlfile"]= $null
				}
			} #
		}
		} #sw
	}


	if($mml.Count -eq 1){

		$value["mmlfile"]= $mml.Values
	}else{
		$value["mmlfile"]= $mml[[string]$listbox_mml.SelectedItem] # キャスト必要
	}

	if($ply.Count -eq 1){

		$value["player"]= $ply.Values
	}else{
		$value["player"]= $ply[[string]$listbox_ply.SelectedItem]
	}

	if($dmc.Count -eq 1){

		$value["dmcdir"]= $dmc.Values
	}else{
		$value["dmcdir"]= $dmc[[string]$listbox_dmc.SelectedItem]
	}

	if($edt.Count -eq 1){

		$value["editor"]= $edt.Values
	}else{
		$value["editor"]= $edt[[string]$listbox_edt.SelectedItem]
	}

} #func
 
function file_writer([string]$xml_file){ 

	# Write-Host $xml.OuterXml # チェック時


	# static Xml.XmlWriter 静的メンバのため
	$xml_sav= [Xml.XmlWriter]::Create($xml_file, $set_xml)

	$xml.Save($xml_sav)

	$xml_sav.Close()

} #func
  
$ErrorActionPreference= "Stop" 
try{
 
Add-Type -AssemblyName System.Windows.Forms | Out-Null 
 
# XmlWriterSetting ------ 

# Xml名前空間WriterSettingクラス
$set_xml= New-Object System.Xml.XmlWriterSettings

# クラスのプロパティ
$set_xml.Indent= $true
$set_xml.IndentChars= ("`t") # \t
$set_xml.Encoding= [Text.Encoding]::UTF8 # default= UTF8で出力 / shift_jis ha err
 
# sub Form ============ 
	
$sub_mnu= New-Object System.Windows.Forms.MenuStrip 

$sub_menu_f= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_f.Text= "ファイル"

$sub_menu_a= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_a.Text= "設定リセット"

$sub_menu_a.Add_Click({	# 設定リセット

	[string]$ret= [Windows.Forms.MessageBox]::Show(

		"環境設定のリセット", "確認", "OKCancel","Information","Button2"
	)

	switch($ret){

	'OK'{
		$xml= [xml]$xml_string

		$value= @{}; $box= @{}; $mml= @{};
		$mck= @{}; $nsd= @{}; $pmd= @{};
		$ply= @{}; $dmc= @{}; $edt= @{};

		xml_read $xml.table
		hash_read_all
	}
	#'Cancel'{}

	} #sw
})

$sub_menu_sn=New-Object System.Windows.Forms.ToolStripSeparator
$sub_menu_n= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_n.Text= "設定終了"

$sub_menu_n.Add_Click({	# 設定終了

	$sub_f.DialogResult= "OK"

	$sub_f.Close() #.Add_Closingへ
})


$sub_menu_o= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_o.Text= "PMD Option"

$sub_menu_opn= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_opn.Text= "OPN 4op"
$sub_menu_opn.Add_Click({

	$box["option"]= "opn"
	pmd_option
})

$sub_menu_opl= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_opl.Text= "OPL 2op"
$sub_menu_opl.ForeColor= "Gray"
$sub_menu_opl.Add_Click({

	$box["option"]= "opl"
	pmd_option
})

$sub_menu_sa=New-Object System.Windows.Forms.ToolStripSeparator

$sub_menu_opm= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_opm.Text= "OPM 4op"
$sub_menu_opm.ForeColor= "Gray"
$sub_menu_opm.Add_Click({

	$box["option"]= "opm"
	pmd_option
})

$sub_menu_towns= New-Object System.Windows.Forms.ToolStripMenuItem
$sub_menu_towns.Text= "TOWNS 4op"
$sub_menu_towns.ForeColor= "Gray"
$sub_menu_towns.Add_Click({

	$box["option"]= "towns"
	pmd_option
})
 
$baloon= New-Object System.Windows.Forms.Tooltip 
$baloon.ShowAlways= $false
# $baloon.ToolTipIcon= "Info"
$baloon.ToolTipTitle= 'Path: '
$baloon.AutomaticDelay= 667
 
$tab= New-Object System.Windows.Forms.TabControl 
$tab.Size= "225,205"
$tab.Location= "5,25"
 
# tab_mml 
	
$tab_mml= New-Object System.Windows.Forms.TabPage 
$tab_mml.Text= "mml"
 
$label_mml= New-Object System.Windows.Forms.Label 
$label_mml.Text= "MMLファイル"
$label_mml.Size= "190,15"
$label_mml.Location= "10,5"
 
$contxt_mml= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_mml.Items.Add("Cancel")
[void]$contxt_mml.Items.Add("Editor")
[void]$contxt_mml.Items.Add("Folder")
[void]$contxt_mml.Items.Add("Remove")

$contxt_mml.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_mml.SelectedItem= $null

		break;
	}'Remove'{
		$mml.Remove([string]$listbox_mml.SelectedItem)
		$listbox_mml.Items.Remove([string]$listbox_mml.SelectedItem)

		break;
	}'Folder'{
		if($listbox_mml.SelectedItem -ne $null){

			folder_open 1 $mml[[string]$listbox_mml.SelectedItem]
		}
		break;
	}'Editor'{
		if($listbox_mml.SelectedItem -ne $null){

			editor_open $edt[[string]$listbox_edt.SelectedItem] $mml[[string]$listbox_mml.SelectedItem]
		}
	}
	} #sw

	$contxt_mml.Close()
})
 
$listbox_mml= New-Object System.Windows.Forms.ListBox 
$listbox_mml.Size= "200,60"
$listbox_mml.Location= "5,30"

$listbox_mml.AllowDrop= $true

$listbox_mml.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_mml,$mml[[string]$listbox_mml.SelectedItem])
	}
})

$listbox_mml.Add_MouseDoubleClick({

	editor_open $edt[[string]$listbox_edt.SelectedItem] $mml[[string]$listbox_mml.SelectedItem]
})

$listbox_mml.Add_MouseDown({

	if([string]$_.Button -eq "Right"){
		# $contxt objを読み込んだ後$listbox objが安全
		$contxt_mml.Show([Windows.Forms.Cursor]::Position)
	}
})

$listbox_mml.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_mml.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "mml" $drop
})
 
$label_dmc= New-Object System.Windows.Forms.Label 
$label_dmc.Text= "DMC,PMD/includeフォルダ"
$label_dmc.Size= "190,15"
$label_dmc.Location= "10,95"
 
$contxt_dmc= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_dmc.Items.Add("Cancel")
[void]$contxt_dmc.Items.Add("Folder")
[void]$contxt_dmc.Items.Add("Remove")

$contxt_dmc.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_dmc.SelectedItem= $null

		break;
	}'Remove'{
		$dmc.Remove([string]$listbox_dmc.SelectedItem)
		$listbox_dmc.Items.Remove([string]$listbox_dmc.SelectedItem)

		break;
	}'Folder'{

		if($listbox_dmc.SelectedItem -ne $null){

			folder_open 1 $dmc[[string]$listbox_dmc.SelectedItem]
		}
	}
	} #sw

	$contxt_dmc.Close()
})
 
$listbox_dmc= New-Object System.Windows.Forms.ListBox 
$listbox_dmc.Size= "200,60"
$listbox_dmc.Location= "5,120"

$listbox_dmc.AllowDrop= $true

$listbox_dmc.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_dmc, $dmc[[string]$listbox_dmc.SelectedItem])
	}
})

$listbox_dmc.Add_MouseDoubleClick({

	folder_open 1 $dmc[[string]$listbox_dmc.SelectedItem]
})

$listbox_dmc.Add_MouseDown({

	if([string]$_.Button -eq "Right"){

		$contxt_dmc.Show([Windows.Forms.Cursor]::Position)
	}
})

$listbox_dmc.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_dmc.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "dmc" $drop
})
  
# tab_bin 
	
$tab_bin= New-Object System.Windows.Forms.TabPage 
$tab_bin.Text= "bin"
 
$radio_grp= New-Object System.Windows.Forms.GroupBox 
$radio_grp.Text= "mck,NSD,PMD"
$radio_grp.Size= "120,105"
$radio_grp.Location= "10,5"
 
<# $label_bin= New-Object System.Windows.Forms.Label 
$label_bin.Text= "コンパイラファイル"
$label_bin.Size= "190,15"
$label_bin.Location= "10,95"
#>
 
# mck ------ 
	
$radio_mck= New-Object System.Windows.Forms.RadioButton 
$radio_mck.Text= "ppmck"
$radio_mck.Size= "65,20"
$radio_mck.Location= "20,20"

$radio_mck.Add_CheckedChanged({

	$listbox_nsd.Hide()
	$listbox_pmd.Hide()
	$listbox_mck.Show()

	foreach($key in $mck.Keys){

		if($mck[$key]  -eq $value["compiler"]){ $listbox_mck.SelectedItem= $key }
	} #
})
 
$contxt_mck= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_mck.Items.Add("Cancel")
[void]$contxt_mck.Items.Add("Folder")
[void]$contxt_mck.Items.Add("Remove")

$contxt_mck.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_mck.SelectedItem= $null

		break;
	}'Remove'{
		$mck.Remove([string]$listbox_mck.SelectedItem)
		$listbox_mck.Items.Remove([string]$listbox_mck.SelectedItem)

		break;
	}'Folder'{
		if($listbox_mck.SelectedItem -ne $null){

			folder_open 1 $mck[[string]$listbox_mck.SelectedItem]
		}
	}
	} #sw

	$contxt_mck.Close()
})
 
$listbox_mck= New-Object System.Windows.Forms.ListBox 
$listbox_mck.Size= "200,60"
$listbox_mck.Location= "5,120"

$listbox_mck.AllowDrop= $true

$listbox_mck.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_mck,$mck[[string]$listbox_mck.SelectedItem])
	}
})

$listbox_mck.Add_MouseDoubleClick({

	folder_open 1 $mck[[string]$listbox_mck.SelectedItem]
})

$listbox_mck.Add_MouseDown({

	if([string]$_.Button -eq "Right"){

		$contxt_mck.Show([Windows.Forms.Cursor]::Position)
	}
})

$listbox_mck.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_mck.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "mck" $drop
})
  
# nsd ------ 
	
$radio_nsd= New-Object System.Windows.Forms.RadioButton 
$radio_nsd.Text= "NSDlib"
$radio_nsd.Size= "65,20"
$radio_nsd.Location= "20,45" # $from radio_grp Location

$radio_nsd.Add_CheckedChanged({

	$listbox_mck.Hide()
	$listbox_pmd.Hide()
	$listbox_nsd.Show()

	foreach($key in $nsd.Keys){

		if($nsd[$key]  -eq $value["compiler"]){ $listbox_nsd.SelectedItem= $key }
	} #
})
 
$contxt_nsd= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_nsd.Items.Add("Cancel")
[void]$contxt_nsd.Items.Add("Folder")
[void]$contxt_nsd.Items.Add("Remove")

$contxt_nsd.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_nsd.SelectedItem= $null

		break;
	}'Remove'{
		$nsd.Remove([string]$listbox_nsd.SelectedItem)
		$listbox_nsd.Items.Remove([string]$listbox_nsd.SelectedItem)

		break;
	}'Folder'{
		if($listbox_nsd.SelectedItem -ne $null){

			folder_open 1 $nsd[[string]$listbox_nsd.SelectedItem]
		}
	}
	} #sw

	$contxt_nsd.Close()
})
 
$listbox_nsd= New-Object System.Windows.Forms.ListBox 
$listbox_nsd.Size= "200,60"
$listbox_nsd.Location= "5,120"

$listbox_nsd.AllowDrop= $true

$listbox_nsd.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_nsd,$nsd[[string]$listbox_nsd.SelectedItem])
	}
})

$listbox_nsd.Add_MouseDoubleClick({

	folder_open 1 $nsd[[string]$listbox_nsd.SelectedItem]
})

$listbox_nsd.Add_MouseDown({

	if([string]$_.Button -eq "Right"){

		# [Windows.Forms.Control]::MousePosition | write-host #でも同じ
		$contxt_nsd.Show([Windows.Forms.Cursor]::Position) # [.X, .Y]
	}
})

$listbox_nsd.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_nsd.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "nsd" $drop
})
  
# pmd ------ 
	
$radio_pmd= New-Object System.Windows.Forms.RadioButton 
$radio_pmd.Text= "P.M.D"
$radio_pmd.Size= "65,20"
$radio_pmd.Location= "20,70"

$radio_pmd.Add_CheckedChanged({

	$listbox_mck.Hide()
	$listbox_nsd.Hide()
	$listbox_pmd.Show()

	foreach($key in $pmd.Keys){

		if($pmd[$key]  -eq $value["compiler"]){ $listbox_pmd.SelectedItem= $key }
	} #
})
 
$contxt_pmd= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_pmd.Items.Add("Cancel")
[void]$contxt_pmd.Items.Add("Folder")
[void]$contxt_pmd.Items.Add("Remove")

$contxt_pmd.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_pmd.SelectedItem= $null

		break;
	}'Remove'{
		$pmd.Remove([string]$listbox_pmd.SelectedItem)
		$listbox_pmd.Items.Remove([string]$listbox_pmd.SelectedItem)

		break;
	}'Folder'{
		if($listbox_pmd.SelectedItem -ne $null){

			folder_open 1 $pmd[[string]$listbox_pmd.SelectedItem]
		}
	}
	} #sw

	$contxt_pmd.Close()
})
 
$listbox_pmd= New-Object System.Windows.Forms.ListBox 
$listbox_pmd.Size= "200,60"
$listbox_pmd.Location= "5,120"

$listbox_pmd.AllowDrop= $true

$listbox_pmd.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_pmd,$pmd[[string]$listbox_pmd.SelectedItem])
	}
})

$listbox_pmd.Add_MouseDoubleClick({

	folder_open 1 $pmd[[string]$listbox_pmd.SelectedItem]
})

$listbox_pmd.Add_MouseDown({

	if([string]$_.Button -eq "Right"){

		$contxt_pmd.Show([Windows.Forms.Cursor]::Position)
	}
})

$listbox_pmd.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_pmd.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "pmd" $drop
})
   
# tab_ply 
	
$tab_ply= New-Object System.Windows.Forms.TabPage 
$tab_ply.Text= "player"
 
$label_ply= New-Object System.Windows.Forms.Label 
$label_ply.Text= "プレイヤーファイル"
$label_ply.Size= "190,15"
$label_ply.Location= "10,5"
 
$contxt_ply= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_ply.Items.Add("Cancel")
[void]$contxt_ply.Items.Add("Open")
[void]$contxt_ply.Items.Add("Folder")
[void]$contxt_ply.Items.Add("Remove")

$contxt_ply.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_ply.SelectedItem= $null

		break;
	}'Remove'{
		$ply.Remove([string]$listbox_ply.SelectedItem)
		$listbox_ply.Items.Remove([string]$listbox_ply.SelectedItem)

		break;
	}'Folder'{
		if($listbox_ply.SelectedItem -ne $null){

			folder_open 1 $ply[[string]$listbox_ply.SelectedItem]
		}
		break;
	}'Open'{
		if($listbox_ply.SelectedItem -ne $null){

			folder_open 0 $ply[[string]$listbox_ply.SelectedItem]
		}
	}
	} #sw

	$contxt_ply.Close()
})
 
$listbox_ply= New-Object System.Windows.Forms.ListBox 
$listbox_ply.Size= "200,60"
$listbox_ply.Location= "5,30"

$listbox_ply.AllowDrop= $true

$listbox_ply.Add_MouseUp({

	if([string]$_.Button -eq "Left"){

		$baloon.SetToolTip($listbox_ply,$ply[[string]$listbox_ply.SelectedItem])
	}
})

$listbox_ply.Add_MouseDoubleClick({

	folder_open 0 $ply[[string]$listbox_ply.SelectedItem]
})

$listbox_ply.Add_MouseDown({

	if([string]$_.Button -eq "Right"){

		$contxt_ply.Show([Windows.Forms.Cursor]::Position)
	}
})

$listbox_ply.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_ply.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "ply" $drop
})
 
$stop_box= New-Object System.Windows.Forms.CheckBox 
$stop_box.Text= "stopコマンド(nsfplay,winamp)"
$stop_box.Size= "200,20"
$stop_box.Location= "10,95"
 
$label_ply_read= New-Object System.Windows.Forms.Label 
$label_ply_read.Text= "※コンパイル時、stopコマンド"
$label_ply_read.Size= "190,15"
$label_ply_read.Location= "10,155"
  
# tab_edt 
	 
$tab_edt= New-Object System.Windows.Forms.TabPage 
$tab_edt.Text= "editor"
 
$label_edt= New-Object System.Windows.Forms.Label 
$label_edt.Text= "エディタ登録"
$label_edt.Size= "190,15"
$label_edt.Location= "10,5"
 
$contxt_edt= New-Object System.Windows.Forms.ContextMenuStrip 

[void]$contxt_edt.Items.Add("Cancel")
[void]$contxt_edt.Items.Add("Open")
[void]$contxt_edt.Items.Add("Folder")
[void]$contxt_edt.Items.Add("Remove")

$contxt_edt.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # キャスト必要

	'Cancel'{
		$listbox_edt.SelectedItem= $null

		break;
	}'Remove'{
		$edt.Remove([string]$listbox_edt.SelectedItem)
		$listbox_edt.Items.Remove([string]$listbox_edt.SelectedItem)

		break;
	}'Folder'{
		if($listbox_edt.SelectedItem -ne $null){

			folder_open 1 $edt[[string]$listbox_edt.SelectedItem]
		}
		break;
	}'Open'{
		if($listbox_edt.SelectedItem -ne $null){

			folder_open 0 $edt[[string]$listbox_edt.SelectedItem]
		}
	}
	} #sw

	$contxt_edt.Close()
})
 
$listbox_edt= New-Object System.Windows.Forms.ListBox 
$listbox_edt.Size= "200,60"
$listbox_edt.Location= "5,30"

$listbox_edt.AllowDrop= $true

$listbox_edt.Add_MouseUp({

	if([string]$_.Button -eq "Left"){
		$baloon.SetToolTip($listbox_edt,$edt[[string]$listbox_edt.SelectedItem])
	}
})

$listbox_edt.Add_MouseDoubleClick({

	folder_open 0 $edt[[string]$listbox_edt.SelectedItem]
})

$listbox_edt.Add_MouseDown({

	if([string]$_.Button -eq "Right"){ $contxt_edt.Show([Windows.Forms.Cursor]::Position) }
})

$listbox_edt.Add_DragEnter({

	$_.Effect= "All"
})

$listbox_edt.Add_DragDrop({

	[array]$drop= $_.Data.GetData("FileDrop")

	drag_drop "edt" $drop
})
 
$label_edt_read= New-Object System.Windows.Forms.Label 
$label_edt_read.Text= "※エディタ、mmlリスト右クリック"
$label_edt_read.Size= "190,15"
$label_edt_read.Location= "10,155"
# $label_edt_read.ForeColor= "Gray"
# $label_edt_read.BackColor= "White"

  
$ok_btn= New-Object System.Windows.Forms.Button 
$ok_btn.Text= "OK"
$ok_btn.Size= "75,25"
$ok_btn.Location= "60,235"

$ok_btn.DialogResult= [Windows.Forms.DialogResult]::OK

$ok_btn.Add_Click({

	# $_.Cancel= $true # 不要
	$sub_f.Close() #.Add_Closingへ
})
 
$cancel_btn= New-Object System.Windows.Forms.Button 
$cancel_btn.Text= "Cancel"
$cancel_btn.Size= "75,25"
$cancel_btn.Location= "140,235"

$cancel_btn.DialogResult= [Windows.Forms.DialogResult]::Cancel

$cancel_btn.Add_Click({

	# $_.Cancel= $true # 不要
	$sub_f.Close() #.Add_Closingへ
})
 
$sub_f= New-Object System.Windows.Forms.Form 
$sub_f.Text= "オプション設定"
$sub_f.Size= "240,300"
$sub_f.Location= "150,0"
$sub_f.FormBorderStyle= "FixedSingle"
$sub_f.StartPosition= "WindowsDefaultLocation"
$sub_f.MaximizeBox= $false
$sub_f.MinimizeBox= $false

$sub_f.TopLevel= $true
$sub_f.Owner= $frm

$sub_f.Add_Closing({

	# Write-Host $sub_f.DialogResult
	switch($sub_f.DialogResult){ # 選択botann

	#'None'{}
	'Cancel'{

		$value= @{}; $box= @{}; $mml= @{};
		$mck= @{}; $nsd= @{}; $pmd= @{};
		$ply= @{}; $dmc= @{}; $edt= @{};

		xml_read $xml.table

		break;
	}'OK'{
		write_value

		$chk_stus= status_cheker
		$chk_mml= wait_setpath $chk_stus


		write_xml $xml.table
		file_writer '.\mml_watch.xml'
	}
	} #sw


	if($chk_mml -eq $true){ # $wait_btn canceller

		toggle_sw 1 "true"
	}

	play_nsf 1 $wait.Filter # Watches:

	$file_drop= $true

	$sub_f.Hide() #.Visible= $false
})
  
# sub_f ShowDialog 

	$sub_menu_f.DropDownItems.AddRange(@($sub_menu_a,$sub_menu_sn,$sub_menu_n))
	$sub_menu_o.DropDownItems.AddRange(@($sub_menu_opn,$sub_menu_sa,$sub_menu_opl,$sub_menu_opm,$sub_menu_towns))
	$sub_mnu.Items.AddRange(@($sub_menu_f,$sub_menu_o))


	$tab_mml.Controls.AddRange(@($label_mml,$listbox_mml,$label_dmc,$listbox_dmc))

	$radio_grp.Controls.AddRange(@($radio_mck,$radio_nsd,$radio_pmd))
	$tab_bin.Controls.AddRange(@($radio_grp,$listbox_mck,$listbox_nsd,$listbox_pmd))

	$tab_ply.Controls.AddRange(@($label_ply,$listbox_ply,$stop_box,$label_ply_read))
	$tab_edt.Controls.AddRange(@($label_edt,$listbox_edt,$label_edt_read))


	$tab.Controls.AddRange(@($tab_mml,$tab_bin,$tab_ply,$tab_edt))

	$sub_f.Controls.AddRange(@($sub_mnu,$tab,$ok_btn,$cancel_btn))
	$sub_f.CancelButton= $cancel_btn
	$sub_f.AcceptButton= $ok_btn
 
# Form ============ 
	
$mnu= New-Object System.Windows.Forms.MenuStrip 

$menu_f= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_f.Text= "ファイル"

$menu_e= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_e.Text= "エディタ"

$menu_e.Add_Click({ # エディタ

	editor_open $value["editor"] $value["mmlfile"]
})


$menu_sn= New-Object System.Windows.Forms.ToolStripSeparator
$menu_n=  New-Object System.Windows.Forms.ToolStripMenuItem
$menu_n.Text= "終了"

$menu_n.Add_Click({ # 終了

	$frm.Close()
})


$menu_o= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_o.Text= "オプション"

$menu_a= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_a.Text= "環境設定"

$menu_a.Add_Click({ # 環境設定

	$file_drop= $false

	toggle_sw 1 "false" # ファイル更新キャンセラー

	write_xml $xml.table # キャンセル時ため、一時退避
	hash_read_all

	drag_drop "mml" $value["mmlfile"] # mmlListへの自動登録


	$ok_btn.Select()	# forcus
	$sub_f.ShowDialog()
})


$menu_st= New-Object System.Windows.Forms.ToolStripSeparator
$menu_t=  New-Object System.Windows.Forms.ToolStripMenuItem
# $menu_t.Text= "v 最前面表示" # top_most

$menu_t.Add_Click({	# 最前面表示

	if($box["chk_topmost"] -eq "true"){ # トグルのため逆

		top_most "false"
	}else{
		top_most "true"
	}
})
 
$wait_lbl= New-Object System.Windows.Forms.Label 
$wait_lbl.Size= "150,25"
$wait_lbl.Location= "0,25"
$wait_lbl.TextAlign= "MiddleCenter"
$wait_lbl.BorderStyle= "Fixed3D"
 
$wait_btn= New-Object System.Windows.Forms.Button 
$wait_btn.Size= "75,25"
$wait_btn.Location= "35,55"
$wait_btn.FlatStyle= "Popup"

$wait_btn.Add_Click({	# 監視ボタン

	if($chk_mml -eq $true){

		if($wait.EnableRaisingEvents -eq $false){ # トグルのため逆

			play_nsf 0 $value["mmlfile"]
			toggle_sw 1 "true"

			play_nsf 1 $wait.Filter # Watches:
		}else{

			toggle_sw 1 "false"
		}
	}
})
 
$frm= New-Object System.Windows.Forms.Form 
$frm.Text= "コントロール"
$frm.Size= "150,120"
$frm.FormBorderStyle= "FixedSingle"
$frm.StartPosition= "WindowsDefaultLocation"
$frm.ShowIcon= $false
$frm.MinimizeBox= $true
$frm.MaximizeBox= $false

$frm.TopLevel= $true
# $frm.TopMost= $true # 最前面表示のプロパティ
# $frm.Add_Shown({ $frm.WindowState= "Minimized" }) # 最小化

# $frm.Add_KeyDown({
#
#	write-host $_.KeyCode # test yhou
# })


$frm.AllowDrop= $true

$frm.Add_DragEnter({

	$_.Effect= "All"
})

$frm.Add_DragDrop({

	if($file_drop -eq $true){ # 環境設定時、$false


		toggle_sw 1 "false"

		[array]$drop= $_.Data.GetData("FileDrop")

		$value["mmlfile"]= [string]$drop[0]

		Write-Host ''


		$chk_stus[0]= console_out "mml" $value["mmlfile"]

		$chk_mml= wait_setpath $chk_stus


		if($chk_mml -eq $true){

			play_nsf 0 $value["mmlfile"]

			toggle_sw 1 "true"
		}

		play_nsf 1 $wait.Filter # Watches:
	}
})

$frm.Add_Closing({

	write_xml $xml.table
	file_writer '.\mml_watch.xml'

	$sub_f.Dispose()
})
  
# form ShowDialog 

$menu_f.DropDownItems.AddRange(@($menu_e,$menu_sn,$menu_n))
$menu_o.DropDownItems.AddRange(@($menu_a,$menu_st,$menu_t))
$mnu.Items.AddRange(@($menu_f,$menu_o))

$frm.Controls.AddRange(@($mnu,$wait_lbl,$wait_btn))
 
# FileSystemWatcher ------ 

$wait= New-Object System.IO.FileSystemWatcher
$wait.SynchronizingObject= $frm

# $wait.InternalBufferSize= 8192 # [4096-8192-65535]
# $wait.IncludeSubdirectories= $false


$wait.NotifyFilter= [IO.NotifyFilters]::LastWrite

[string]$lated_time= ""
[string]$chk_time= ""


$wait.Add_Changed({	# event func入れ子は一段が理想..

	$lated_time= (Get-Item $_.FullPath).LastWriteTime.ToString('yy/MM/dd HH:mm:ss')


	if($lated_time -ne $chk_time){ # 二重読込みの不備対策

		# $_ | write-host  # [= FileSystemEventArgsクラス]
		# $_ | get-member -type Property | write-host


		Write-Host ('Updated: '+ $_.ChangeType+ "`r`n")


		play_nsf 0 $_.FullPath

		play_nsf 1 $_.Name # Watches:
		sleep -m 240	# ウェイト

		$chk_time= $lated_time
	}
})
 
# main ============ 

cd (Split-Path -Parent $MyInvocation.MyCommand.Path)
[Environment]::CurrentDirectory= pwd # working_dir set


# キャスト

if((Test-Path '.\mml_watch.xml') -eq $true){

	$xml= [xml](cat '.\mml_watch.xml')
}else{
	$xml= [xml]$xml_string
}


# 連想配列化

$value= @{}; $box= @{}; $mml= @{};
$mck= @{}; $nsd= @{}; $pmd= @{};
$ply= @{}; $dmc= @{}; $edt= @{};


xml_read $xml.table


# 状態チェック
top_most $box["chk_topmost"]	# 最前面


# innsuu areba

[string]$args_path= $Args[0]
if($args_path -ne ""){ $value["mmlfile"]= $args_path } # $null -> ""


[array]$chk_stus= status_cheker

[bool]$chk_mml= wait_setpath $chk_stus


# $wait_btn canceller
if($chk_mml -eq $true){

	toggle_sw 0 "true"
}else{
	toggle_sw 0 "false"
}

play_nsf 1 $wait.Filter # Watches:

[bool]$file_drop= $true # D&D canceller
 
$frm.ShowDialog() | Out-Null 

 # | Out-Null =[ > $null] cancel標準出力抑制

 
}catch [Exception]{	# err_all 

	echo $_.exception
	Read-Host "続けるにはENTERを押して下さい" | Out-Null
}
 

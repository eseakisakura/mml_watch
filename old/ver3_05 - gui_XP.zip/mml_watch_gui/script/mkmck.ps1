﻿<# mkmck.ps1 #> 

[array]$r= $Args	# mml,bin,dmc

[string[]]$arr= .\split_path.ps1 $r[1]
[string[]]$ary= .\split_path.ps1 $arr[1] # 親の親


if((Test-Path ($ary[1]+ '\bin')) -eq $false){	# pushdのエラー回避

	Write-Host ("`r`n"+ 'mkmck.ps1>> binフォルダが見つからない')
	$LASTEXITCODE= 4

}else{
	[string]$Env:DMC_INCLUDE= $r[2]	# パス対応素でよし

	pushd $ary[1]

	[string]$Env:PPMCK_BASEDIR= '.\'
	[string]$Env:NES_INCLUDE= '.\nes_include'

	[string]$exe_ppmckc= '.\bin\ppmckc.exe'
	[string]$exe_nesasm= '.\bin\nesasm.exe'


	if((Test-Path $exe_ppmckc) -eq $false){

		Write-Host ("`r`n"+ 'mkmck.ps1>> ppmckc.exeが見つかりません')
		$LASTEXITCODE= 3

	}else{
		if((Test-Path .\effect.h) -eq $true){ del .\effect.h }

		& $exe_ppmckc -i ("`""+ $r[0]+ ".mml`"") | Write-Host	# esc[`"] 空白パス対応
		sleep -m 120


		if($LASTEXITCODE -eq 0){

			if((Test-Path $exe_nesasm) -eq $false){

				Write-Host ("`r`n"+ 'mkmck.ps1>> nesasm.exeが見つかりません')
				$LASTEXITCODE= 2

			}else{
				if((Test-Path .\ppmck.nes) -eq $true){ del .\ppmck.nes }

				& $exe_nesasm -s -raw .\ppmck.asm | Write-Host	# Command
				sleep -m 120

				if($LASTEXITCODE -eq 0){

					move -force .\ppmck.nes ($r[0]+ '.nsf')

					del .\effect.h
					del .\define.inc
					del ($r[0]+ '.h')
				}
			}
		}
	}

	popd # mml_watchへ
}

exit $LASTEXITCODE
 

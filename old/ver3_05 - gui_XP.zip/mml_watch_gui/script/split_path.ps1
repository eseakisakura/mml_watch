﻿<# split_path.ps1 #>

[string]$f= $Args[0]
[string[]]$out= "","","",""

$out[0]= [IO.Path]::GetFileName($f)
$out[1]= [IO.Path]::GetDirectoryName($f)
$out[2]= [IO.Path]::GetFileNameWithoutExtension($f)
$out[3]= [IO.Path]::GetExtension($f)

return $out

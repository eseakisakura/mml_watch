﻿<# mknsd.ps1 #> 

[string[]]$r= $Args	# mml,bin,dmc

[string[]]$arr= .\split_path.ps1 $r[1]
[string]$exe_nsc= '.\'+ $arr[0]


if($exe_nsc -ne '.\nsc.exe'){	# compiler chk

	Write-Host ("`r`n"+ '"mknsd.ps1">> nsc.exeが見つかりません')
	$LASTEXITCODE= 3


}elseif((Test-Path $r[1]) -eq $false){	# compiler path chk

	Write-Host ("`r`n"+ '"mknsd.ps1">> '+ $exe_nsc+ 'がパス上にありません')
	$LASTEXITCODE= 2


}else{
	[string]$Env:DMC_INCLUDE= $r[2]	# パス対応素でよし


	pushd $arr[1]

	# [IO.Directory]::SetCurrentDirectory((pwd))		# nsc 端末カレント認識あらばセット
	# write-host "[IO.Directory]::GetCurrentDirectory()"	# cd chk

	& $exe_nsc -n -e ('"'+ $r[0]+ '.mml"') | write-host	# Command時、[&]必要
	sleep -m 240	# 異常時用ウェイト

	# [IO.Directory]::SetCurrentDirectory([Environment]::CurrentDirectory)	# mml_wchへ

	popd	# mml_watchへ
}

exit $LASTEXITCODE
 

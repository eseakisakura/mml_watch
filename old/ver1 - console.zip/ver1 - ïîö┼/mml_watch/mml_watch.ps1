<# mml_watch.ps1 ������ #>

[array]$Args_path = $Args

$w = New-Object System.IO.FileSystemWatcher
$w.Path = $Args_path[1]
$w.Filter = $Args_path[2]
$w.NotifyFilter = [System.IO.NotifyFilters]::LastWrite

while(1){
	.\nsf_trans.bat $Args_path[0] # Command

	echo ""
	echo "Setting up watches."
	echo "Watches established.`r`n"

	$changeResult = $w.WaitForChanged([System.IO.WatcherChangeTypes]::Changed)
	echo ($changeResult.Name+ " MODIFY`r`n")

} #

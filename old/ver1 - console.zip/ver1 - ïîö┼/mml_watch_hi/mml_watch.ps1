<# mml_watch.ps1 �񓯊��� #>

$ErrorActionPreference = "Stop"
try{

[array]$Args_path = $Args # $Args overwrite after

.\nsf_trans.ps1 $Args_path[0] # Command

while(1){

	Add-Type -AssemblyName System.Windows.Forms | Out-Null
	$m = New-Object System.Windows.Forms.Form
	$m.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
	$m.ShowInTaskbar = $false

	$w = New-Object System.IO.FileSystemWatcher
	$w.Path = $Args_path[1]
	$w.Filter = $Args_path[2]
	$w.NotifyFilter = [System.IO.NotifyFilters]::LastWrite
	$w.SynchronizingObject = $m


	$w.add_Changed({ # �C�x���g

		Write-Host ($_.Name+ " MODIFY`r`n")

		.\nsf_trans.ps1 $Args_path[0] # Command

		$w.EnableRaisingEvents = $false # �I��
		$m.Dispose()
	})

	Write-Host ""
	Write-Host "Setting up watches."
	Write-Host "Watches established.`r`n"

	$w.EnableRaisingEvents = $true # �J�n
	[void]$m.ShowDialog()

} #
}
catch [Exception]{ #err_all
	Write-Host $_.exception
	Read-Host "������ɂ�ENTER�L�[�������ĉ�����" | Out-Null
}

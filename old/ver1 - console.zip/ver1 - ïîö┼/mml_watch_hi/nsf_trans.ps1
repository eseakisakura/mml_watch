<# nsf_trans.ps1 #>
cd (Split-Path -Parent $MyInvocation.MyCommand.Path)


#[string]$exe_player= "..\..\nsfplay\nsfplay.exe"
[string]$exe_player= "..\..\VirtuaNSF\VirtuaNSF.exe"


[string]$nsf= "`""+ $Args[0]+ ".nsf`"" # esc[`"]

function err_chk([int]$ErrLev){

	Write-Host ""
	Write-Host ("exitcode :"+ $ErrLev)

	if($ErrLev -ne 0){
		Write-Host ""
		Write-Host "// NSFfile: failure !//"
	}else{

		start $exe_player $nsf
	}
} #func


[string]$exe_nsc= "..\bin\nsc.exe"
[string]$mml= "`""+ $Args[0]+ ".mml`""

if((Test-Path .\mck_script\mknsf.ps1) -eq $true){ # ppmck chk

	.\mck_script\mknsf.ps1 $Args[0] | Write-Host # Command
}else{

	& $exe_nsc -n -e $mml | Write-Host # Command
}

err_chk($LASTEXITCODE)

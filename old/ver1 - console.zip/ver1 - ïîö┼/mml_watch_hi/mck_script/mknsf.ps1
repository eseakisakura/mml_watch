<# mknsf.ps1 #>

[string]$Env:PPMCK_BASEDIR = ".."
[string]$Env:NES_INCLUDE = $Env:PPMCK_BASEDIR+ "\nes_include"
[string]$Env:DMC_INCLUDE = [System.IO.Path]::GetDirectoryName($Args[0])

[string]$exe_ppmckc= $Env:PPMCK_BASEDIR+ "\bin\ppmckc.exe"
[string]$exe_nesasm= $Env:PPMCK_BASEDIR+ "\bin\nesasm.exe"

[string]$mml= "`""+ $Args[0]+ ".mml`"" # exe

if((Test-Path .\effect.h) -eq $true){ del .\effect.h }
& $exe_ppmckc -i $mml # Command

if($? -eq $true){

	if((Test-Path .\ppmck.nes) -eq $true){ del .\ppmck.nes }
	& $exe_nesasm -s -raw .\ppmck.asm # Command

	if($? -eq $true){

		move -force .\ppmck.nes ($Args[0]+ ".nsf")

		del .\effect.h
		del .\define.inc
		del ($Args[0]+ ".h")
	}
}

exit $LASTEXITCODE

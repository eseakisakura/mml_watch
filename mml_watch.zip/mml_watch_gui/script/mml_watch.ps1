<# mml_watch.ps1 #> 

Write-Host ("`"mml watch`"���N�����܂�")

#          filecashe   R/W
# xml > xml.string > hash > gui.value
#         cancel gi              change gi

# obj kakuho no hensuu niha $script: shinai
# func no insuu ha read nomi,
# func deno write de migikaku suruniha naibu de sengenn

#			xml.string
#			reset
#			v
# xml.file	show->	xml.mem		->hash		->List
# $val[""]				[key,value]	[key]
#					foreach etc.
#
#		<- ok			<-close
#		X- cancel
 
$xml_watch= @' 
<table>
	<!-- status / name�͌Œ�l -->
	<val name= "mmlfile" param= ""/>
	<val name= "compiler" param= ""/>
	<val name= "player" param= ""/>
	<val name= "dmcdir" param= ""/>
	<val name= "editor" param= ""/>
	<val name= "dos" param= ""/>
	<br/>
	<box name= "option" param= "opn"/>
	<box name= "radio_bin" param= "nsd"/>
	<box name= "chk_dos" param= "Unchecked"/>
	<box name= "chk_stop" param= "Checked"/>
	<box name= "chk_topmost" param= "False"/>
	<box name= "chk_auto" param= "True"/>
	<br />
</table>
'@
 
# nsf_trans 
	
function Player_stop(){ 


	if($box["chk_stop"] -eq 'Checked'){

		& $val["player"] /stop
	}
} #func
 
function Mck_trans([string]$file){ 


	Player_stop

	Write-Host ''

	[string[]]$eor= "",""
	[string[]]$output= "",""

	# mml,bin,dmc
	$output= .\mkmck.ps1 $file $val["compiler"] $val["dmcdir"]

	sleep -m 60

	$csl_box.Text= $scroll_text+ $output[1]+ "`r`n"+ $output[2]

	$csl_box.SelectionStart= $csl_box.Text.Length
	$csl_box.ScrollToCaret()

	$script:scroll_text= $output[1]+ "`r`n"+ $output[2]+ "`r`n`r`n"


	if($output[0] -ne ""){

		$err_box.Text= $output[0]+ "`r`n"
	}else{

		# $LASTEXITCODE [0-3]
		$eor[0]= ('exitcode: '+ $LASTEXITCODE)

		Write-Host $eor[0]
		$err_box.Text= $eor[0]+ "`r`n"


		[string[]]$arr= Split_path $file
		[string]$dpn= Join-Path $arr[1] $arr[2]

		if($LASTEXITCODE -ne 0){

			$eor[1]= ('ERROR: '+ $arr[0]+ '>> '+ $arr[2]+ '.nsf')
			Write-Host $eor[1]
			Write-Host ''

			$err_box.Text+= $eor[1]+ "`r`n"

		}else{

			& $val["player"] ('"'+ $dpn+ '.nsf"')
		}
	}
 } #func
 
function Nsd_trans([string]$file){ 


	Player_stop # nsfplay2.4 err�_�C�A���O�o��

	Write-Host '' # ���s

	[string[]]$eor= "",""
	[string[]]$output= "",""

	# mml,bin,dmc
	$output= .\mknsd.ps1 $file $val["compiler"] $val["dmcdir"]

	sleep -m 60 # �ُ펞�p�E�F�C�g

	$csl_box.Text= $scroll_text+ $output[1]

	$csl_box.SelectionStart= $csl_box.Text.Length
	$csl_box.ScrollToCaret()

	$script:scroll_text= $output[1]+ "`r`n`r`n"


	if($output[0] -ne ""){ # not err

		$err_box.Text= $output[0]+ "`r`n"
	}else{

		# $LASTEXITCODE [0-3]
		$eor[0]= ('exitcode: '+ $LASTEXITCODE)

		Write-Host $eor[0]
		$err_box.Text= $eor[0]+ "`r`n"


		[string[]]$arr= Split_path $file
		[string]$dpn= Join-Path $arr[1] $arr[2]

		if($LASTEXITCODE -ne 0){

			$eor[1]= ('ERROR: '+ $arr[0]+ '>> '+ $arr[2]+ '.nsf')
			Write-Host $eor[1]
			Write-Host ''

			$err_box.Text+= $eor[1]+ "`r`n"

		}else{
			# '"' �󔒃p�X�Ή�
			& $val["player"] ('"'+ $dpn+ '.nsf"')
		}
	}
 } #func
 
function Pmd_trans([string]$file){ 


	# Player_stop # fmpmd /s -> �_�C�A���O�Ŏ~�܂�

	Write-Host ''

	[string[]]$eor= "",""
	[string[]]$output= "",""

	# mml,bin,dmc
	$output= .\mkpmd.ps1 $file $val["compiler"] $val["dmcdir"] $val["dos"] $box["option"] $box["chk_dos"]

	sleep -m 60

	$csl_box.Text= $scroll_text+ $output[1]

	$csl_box.SelectionStart= $csl_box.Text.Length
	$csl_box.ScrollToCaret()

	$script:scroll_text= $output[1]+ "`r`n`r`n"


	if($output[0] -ne ""){

		$err_box.Text= $output[0]+ "`r`n"
	}else{

		# $LASTEXITCODE [0-3]
		$eor[0]= ('exitcode: '+ $LASTEXITCODE)

		Write-Host $eor[0]
		$err_box.Text= $eor[0]+ "`r`n"


		[string[]]$arr= Split_path $file
		[string]$dpn= Join-Path $arr[1] $arr[2]

		if($LASTEXITCODE -ne 0){

			$eor[1]= ('ERROR: '+ $arr[0]+ '>> '+ $arr[2]+ '.m')
			Write-Host $eor[1]
			Write-Host ''

			$err_box.Text+= $eor[1]+ "`r`n"

		}else{

			& $val["player"] ('"'+ $dpn+ '.m"')
		}
	}
 } #func
 
function Play_nsf([string]$file){ 

	Write-Host ''

	switch(Chk_path $file){

	2{	Write-Host ('ERROR: Null >> '+ $file);		break;
	}1{	Write-Host ('ERROR: Test-Path >> '+ $file);	break;
	}0{
		switch($box["radio_bin"]){
		'mck'{
			Mck_trans $file;	break;
		}'nsd'{
			Nsd_trans $file;	break;
		}'pmd'{
			Pmd_trans $file
		}
		} #sw
	}
	} #sw
 } #func
 
function Watches_nsf([string]$eor){ 

	Write-Host ''
	Write-Host $eor

	$err_box.Text+= $eor # " last de `r`n"�s�v

	$err_box.SelectionStart= $err_box.Text.Length
	$err_box.ScrollToCaret()
 } #func
  
# chk_path 
	 
function Console_out([string[]]$ph){ 


	[int[]]$err= 0,0,0,0

	$err[0]= Chk_path $ph[0]
	$err[1]= Chk_path $ph[1]
	$err[2]= Chk_path $ph[2]
	$err[3]= Chk_path $ph[3]


	[array]$f= "","","",""
	[string[]]$f[0]= "","","",""
	[string[]]$f[1]= "","","",""
	[string[]]$f[2]= "","","",""
	[string[]]$f[3]= "","","",""


	[string[]]$rot= "","","",""

	switch($err[0]){
	2{	$rot[0]= '> mml�t�@�C�� �I������Ă܂���';		break;
	}1{	$rot[0]= '> mml�t�@�C�� �p�X�悪����܂���';		break;
	}0{	$rot[0]= '< mml�t�@�C��'
		$f[0]= Split_path $ph[0]
	}
	} #sw
	switch($err[1]){
	2{	$rot[1]= '> bin�t�@�C�� �I������Ă܂���';		break;
	}1{	$rot[1]= '> bin�t�@�C�� �p�X�悪����܂���';		break;
	}0{	$rot[1]= '< bin�t�@�C��'
		$f[1]= Split_path $ph[1]
	}
	} #sw
	switch($err[2]){
	2{	$rot[2]= '> Player�t�@�C�� �I������Ă܂���';		break;
	}1{	$rot[2]= '> Player�t�@�C�� �p�X�悪����܂���';		break;
	}0{	$rot[2]= '< Player�t�@�C��'
		$f[2]= Split_path $ph[2]
	}
	} #sw
	switch($err[3]){
	2{	$rot[3]= '> Include�t�H���_ �I������Ă܂���';		break;
	}1{	$rot[3]= '> Include�t�H���_ �p�X�悪����܂���';	break;
	}0{	$rot[3]= '< Include�t�H���_'
		$f[3]= Split_path $ph[3]
	}
	} #sw

	Write-Host '' # ���s
	Write-Host $ph[4]
	Write-Host $ph[5]
	Write-Host ''
	Write-Host ($rot[0]+ "`r`n"+ $ph[0]) # full path
	Write-Host ($rot[1]+ "`r`n"+ $ph[1])
	Write-Host ($rot[2]+ "`r`n"+ $ph[2])
	Write-Host ($rot[3]+ "`r`n"+ $ph[3])
	Write-Host ''


	$csl_box.Lines= $ph[4],
			$ph[5],
			"",
			$rot[0],(" : "+ $f[0][0]), # file name
			$rot[1],(" : "+ $f[1][0]),
			$rot[2],(" : "+ $f[2][0]),
			$rot[3],(" : "+ $f[3][0])


	$script:scroll_text= $csl_box.Text

	return $err
} #func
 
function Status_cheker(){ 


	[string]$m= "" # ��`�݂̂��ƕԒl(echo)���o��A��l����Ƃ�
	[string]$k= ""
	[string]$c= ""
	[string]$g= ""
	[array]$arr= 0,0,0,0


	switch($box["radio_bin"]){

		'mck'{	$m= '"ppmck"' # esc["`""] -> ['"']
			break;

		}'nsd'{	$m= '"NSDlib"'
			break;

		}'pmd'{	$m= '"P.M.D"'
			$k= $box["option"]
		}
	} #sw

	if($box["chk_dos"] -eq 'Checked'){

		$g= " /x64�Ή�"
	}

	if($box["chk_stop"] -eq 'Checked'){

		$c= " /stop�R�}���h�t��"
	}


	[string[]]$ss= ('[ '+ $m+ $k+'���[�h ]'),($g+ $c)


	[array]$yy=	$val["mmlfile"],$val["compiler"],$val["player"],$val["dmcdir"],
			$ss[0],$ss[1]

	$arr= Console_out $yy


	return $arr

} #func
 
function Wait_setpath([int[]]$r){ 


	[int]$stus= $r[0]+ $r[1]+ $r[2] # $r[3] cancel -> 000,200
	[int]$err= 1

	Write-Host ''

	switch($stus){
	0{
		[string[]]$f= Split_path $val["mmlfile"]

		switch($f[3]){
		'.mml'{
			$eor= ('.mml�̊Ď����Z�b�g<< '+ $f[0])
			$err= 0; break;

		}'.nsf'{
			$eor= ('.nsf�̊Ď��͕s�ł�>> '+ $f[0])
			break;

		}'.m'{
			$eor= ('.m�̊Ď��͕s�ł�>> '+ $f[0])
			break;

		}default{

			$eor= ('�Ď��Ώۂ́Amml�t�@�C���̂�>> '+ $f[0])
		}
		} #sw
		break;

	}default{ # �N���ł��Ȃ����

		$eor= ('�Ď������s�� ERR Level>> '+ $stus)
	}
	} #sw


	Write-Host $eor
	$err_box.Text= $eor+ "`r`n"

	$frm.Text= "mml watch"


	switch($err){
	0{
		$wait.Path= $f[1]	# RaisingEvents= $True���A�K�v
		$wait.Filter= $f[0]

		return $True
		break;
	}1{
		# $wait.Path= $null  # Path�G���[�ɂȂ�
		$wait.Filter= $null

		return $False
	}
	} #sw


} #func
  
# gui 
	 
function Top_most([string]$t){ 

	switch($t){
	'true'{

		$frm.TopMost= $True # �őO�ʉ�

		$menu_t.Text= "v �őO�ʕ\��"
		break;
	}'false'{

		$frm.TopMost= $False

		$menu_t.Text= "�őO�ʕ\��"
	}
	} #sw

	return $t
 } #func
 
function Auto_start([string]$t){ 

	switch($t){
	'true'{
		$pic_box.Image= [System.Drawing.Image]::FromFile(".\img\orange.png")
		$menu_r.Text= "v �������X�^�[�g"
		break;
	}'false'{
		$pic_box.Image= [System.Drawing.Image]::FromFile(".\img\blue.png")
		$menu_r.Text= "�������X�^�[�g"
	}
	} #sw

	return $t
 } #func
 
function Toggle_label(){ 


	[string]$d= ""

	switch($box["radio_bin"]){

	'mck'{	$d= "MCK / ";	break;
	}'nsd'{	$d= "NSD / ";	break;
	}'pmd'{	$d= "PMD / "
	}
	} #sw

	switch($wait.EnableRaisingEvents){

	$True{		$d+= "WATCHES"
			$tray.Text= $d
			$wait_lbl.Text= $d
			$wait_lbl.BackColor= "orange"
			$wait_lbl.ForeColor= "white"
			break;

	}$False{	$d+= "PAUSE"
			$tray.Text= $d
			$wait_lbl.Text= $d
			$wait_lbl.BackColor= "deepskyblue"
			$wait_lbl.ForeColor= "black"
	}
	} #sw

 } #func
 	
function Toggle_sw([int]$num,[string]$c){ 

 if($num -eq 1){ # w_console out cancel

	switch($c){

	'true'{
		if($wait.EnableRaisingEvents -ne $True){  $num= 0 }
		break;
	}'false'{
		if($wait.EnableRaisingEvents -ne $False){ $num= 0 }
	}
	} #sw
 }

 if($num -eq 0){ # << $num= 0

	switch($c){

	'true'{
		$frm.Text= ("["+ $wait.Filter+ "] - mml watch")
		$wait_btn.Image= [System.Drawing.Image]::FromFile(".\img\stop.png")

		$wait.EnableRaisingEvents= $True # �J�n
		Write-Host ('RaisingEvents: '+ $wait.EnableRaisingEvents)
		break;
	}'false'{
		$frm.Text= "Pause - mml watch"
		$wait_btn.Image= [System.Drawing.Image]::FromFile(".\img\play.png")

		$wait.EnableRaisingEvents= $False
		Write-Host ('RaisingEvents: '+ $wait.EnableRaisingEvents)
	}
	} #sw
 }

 Toggle_label # RaisingEvents check

 } #func
 
function Watch_Setting(){ 

	$frm.AllowDrop= $False

	Toggle_sw 1 "false"	# �t�@�C���X�V�L�����Z���[


	[array]$args_set= "",""
	$args_set= .\setting.ps1 $val $box "all"


	$script:val= $args_set[0]
	$script:box= $args_set[1]

	$script:chk_stus= Status_cheker
	$script:chk_mml= Wait_setpath $chk_stus


	if($chk_mml -eq $True){ # $wait_btn canceller

		Toggle_sw 1 "true"
	}

	# Watches_nsf $wait.Filter # Wait_setpath

	$frm.AllowDrop= $True

 } #func
 
function Watch_Start(){ 

	if($chk_mml -eq $True){

		switch($wait.EnableRaisingEvents){ # �g�O��
		$False{

			if($box["chk_auto"] -ne 'False'){

				Play_nsf $val["mmlfile"]
			}else{
				$err_box.Text= "" # .Clear() reload gi
			}

			Watches_nsf ('< Watches: '+ $wait.Filter)

			Toggle_sw 1 "true"

			break;
		}$True{

			$err_box.Text= "" # .Clear()
			Watches_nsf ('> Pause: '+ $wait.Filter)

			Toggle_sw 1 "false"
		}
		} #sw
	}
 } #func
 
function Watch_Drop(){ 

	Toggle_sw 1 "false"

	[string[]]$args_path= $_.Data.GetData("FileDrop")


	switch(Chk_path $args_path[0]){

	2{	Write-Host ('ERROR: Null >> FileDrop Form')
		break;

	}1{	Write-Host ('ERROR: Test-Path >> FileDrop Form')
		break;

	}0{
		$script:val["mmlfile"]= $args_path[0]
	}
	} #sw

	Write-Host '' # ���s

	$script:chk_stus= Status_cheker

	$script:chk_mml= Wait_setpath $chk_stus


	if($chk_mml -eq $True){

		Toggle_sw 1 "true"
	}

	# Watches_nsf $wait.Filter # Wait_setpath
 } #func
  
# hash 
	
function Wthxml_read($x){ 

  # $x= $script:wth_xml.table

  for([int]$i=5; $i -ge 0; $i--){


	if($x.val[$i].name -ne ''){

		$script:val[$x.val[$i].name]= $x.val[$i].param
	}

	if($x.box[$i].name -ne ''){

		$script:box[$x.box[$i].name]= $x.box[$i].param
	}
  } #
 } #func
 
function Wthwrite_xml($x){ 

  # $x= $script:wth_xml.table

  [array]$val_keys= $val.Keys
  [array]$box_keys= $box.Keys

  [int]$vl= $val_keys.Length
  [int]$bx= $box_keys.Length

  if($vl -gt 6){ Write-Host ('ERROR: val hash >> '+ $vl) }
  if($bx -gt 6){ Write-Host ('ERROR: box hash >> '+ $bx) }



  for([int]$i=5; $i -ge 0; $i--){

	if($i -lt $vl){

		$x.val[$i].name=  [string]$val_keys[$i] # $xml��[string]�L���X�g�K�v
		$x.val[$i].param= [string]$val[$val_keys[$i]]
	}else{
		$x.val[$i].name=  "" # ���ł�
		$x.val[$i].param= ""
	}

	if($i -lt $bx){

		$x.box[$i].name=  [string]$box_keys[$i]
		$x.box[$i].param= [string]$box[$box_keys[$i]]
	}else{
		$x.box[$i].name=  ""
		$x.box[$i].param= ""
	}
  } #
 } #func
  
Add-Type -AssemblyName System.Windows.Forms > $null 

$ErrorActionPreference= "Stop"

cd (Split-Path -Parent $MyInvocation.MyCommand.Path)
[Environment]::CurrentDirectory= pwd # working_dir set
 
# Form 
	 
$err_box= New-Object System.Windows.Forms.TextBox 
$err_box.Size= "220,55"
$err_box.Location= "10,55"
$err_box.WordWrap= "False"
$err_box.Multiline= "True"
$err_box.ScrollBars= "Both"
$err_box.BorderStyle= "FixedSingle"
$err_box.ReadOnly= "True"
#$err_box.ForeColor= "Gray"
$err_box.BackColor= "White"

 
$csl_box= New-Object System.Windows.Forms.TextBox 
$csl_box.Size= "220,145"
$csl_box.Location= "10,115"
$csl_box.WordWrap= "False"
$csl_box.Multiline= "True"
$csl_box.ScrollBars= "Both"
$csl_box.BorderStyle= "FixedSingle"
$csl_box.ReadOnly= "True"
#$csl_box.ForeColor= "Gray"
$csl_box.BackColor= "White"

 
$pic_box = New-Object System.Windows.Forms.PictureBox 
$pic_box.ClientSize= "11,11"
$pic_box.Location= "11,33"
# $pic_box.Image= [System.Drawing.Image]::FromFile(".\img\blue.png")
# $pic_box.Image= [System.Drawing.Image]::FromFile(".\img\orange.png")
 
$wait_lbl= New-Object System.Windows.Forms.Label 
$wait_lbl.Size= "150,25"
#$wait_lbl.Location= "2,25"
$wait_lbl.Location= "61,26"
$wait_lbl.TextAlign= "MiddleCenter"
$wait_lbl.BorderStyle= "Fixed3D"
$wait_lbl.ForeColor= "black"
#$wait_lbl.BackColor= "dodgerblue"

$wait_lbl.Add_Click({
  try{
    if([string]$_.Button -eq 'Left'){

	Watch_Start
    }
  }catch{
	echo $_.exception
  }
})
 
$wait_btn= New-Object System.Windows.Forms.Button 
$wait_btn.Size= "25,25"
#$wait_btn.Location= "158,26"
$wait_btn.Location= "31,26"
$wait_btn.FlatStyle= "Popup"
# $wait_btn.Image= [System.Drawing.Image]::FromFile(".\img\stop.png")
# $wait_btn.Image= [System.Drawing.Image]::FromFile(".\img\play.png")

$wait_btn.Add_Click({	# �Ď��{�^��
  try{
	Watch_Start

  }catch{
	echo $_.exception
  }
 })
 
$contxt_tray= New-Object System.Windows.Forms.ContextMenuStrip 
# $contxt obj��ǂݍ��񂾌�$NotifyIcon obj�����S

[void]$contxt_tray.Items.Add("���ݒ�")
[void]$contxt_tray.Items.Add("�I��")

$contxt_tray.Add_ItemClicked({

	switch([string]$_.ClickedItem){ # �L���X�g�K�v

	'���ݒ�'{
		Watch_Setting
		break;

	}'�I��'{
		$frm.Close()
	}
	} #sw

	$this.Close()
})
 
$tray= New-Object System.Windows.Forms.NotifyIcon 
$tray.Icon= Icon_read "..\mml_watch.exe"
$tray.Visible= $True
#$tray.Text= "watches"
$tray.ContextMenuStrip= $contxt_tray

$tray.Add_MouseDown({

  switch([string]$_.Button){ # �L���X�g

  'Left'{
	switch($frm.WindowState){
	'Minimized'{
		$frm.WindowState= "Normal"
		break;

	}'Normal'{
		$frm.WindowState= "Minimized"

	}
	} #sw

#	break;
#  }'Right'{ # �s�v ���[�_������ -> $tray.ContextMenuStrip
#	$contxt_tray.Show([Windows.Forms.Cursor]::Position)
  }
  } #sw
 })
 
$frm= New-Object System.Windows.Forms.Form 
#$frm.Text= "mml watch"
$frm.Size= "244,302"
$frm.FormBorderStyle= "FixedSingle"
$frm.StartPosition= "WindowsDefaultLocation"
$frm.Icon= Icon_read "..\mml_watch.exe"
#$frm.ShowIcon= $False
#$frm.MinimizeBox= $False
$frm.MaximizeBox= $False

$frm.TopLevel= $True
# $frm.TopMost= $True # �őO�ʕ\���̃v���p�e�B


#$frm.Add_Load({
#	$frm.WindowState= "Minimized" # �ŏ��� "Normal"
#})
#$frm.Add_KeyDown({
#	write-host $_.KeyCode # check
#})

$frm.Add_Shown({

	$wait_btn.Select()	# forcus
 })

$frm.Add_FormClosing({ # event nai dato err ha aku shizurai node kannsuuka
 try{

	Wthwrite_xml $script:wth_xml.table

	File_writer $script:wth_xml '.\mml_watch.xml'

 }catch{
	echo $_.exception
 }
})

$frm.Add_DragEnter({

	$_.Effect= "All"
 })

$frm.AllowDrop= $True

$frm.Add_DragDrop({
  try{
	Watch_Drop

  }catch{
	echo $_.exception
  }
 })
 
$mnu= New-Object System.Windows.Forms.MenuStrip 
	
$menu_f= New-Object System.Windows.Forms.ToolStripMenuItem 
$menu_f.Text= "�t�@�C��"

$menu_e= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_e.Text= "�G�f�B�^"

$menu_e.Add_Click({

	[string]$retn= Editor_open $val["editor"] $val["mmlfile"]

	if($retn -ne ""){ $err_box.Text= $retn }
})

$menu_sd= New-Object System.Windows.Forms.ToolStripSeparator
$menu_d= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_d.Text= "�t�H���_"

$menu_d.Add_Click({

	[string]$retn= Folder_open 1 $val["mmlfile"]

	if($retn -ne ""){ $err_box.Text= $retn }
})

$menu_sn= New-Object System.Windows.Forms.ToolStripSeparator
$menu_n=  New-Object System.Windows.Forms.ToolStripMenuItem
$menu_n.Text= "�I��"

$menu_n.Add_Click({ # �I��

	$frm.Close()
})
 
$menu_o= New-Object System.Windows.Forms.ToolStripMenuItem 
$menu_o.Text= "�I�v�V����"


$menu_a= New-Object System.Windows.Forms.ToolStripMenuItem
$menu_a.Text= "���ݒ�"

$menu_a.Add_Click({ # ���ݒ�

 try{
	Watch_Setting

 }catch{
	echo $_.exception
    	Write-Host '"ERROR: Safety Stopper >> call .\setting.ps1"'
 }
})

$menu_st= New-Object System.Windows.Forms.ToolStripSeparator
$menu_t=  New-Object System.Windows.Forms.ToolStripMenuItem
# $menu_t.Text= "v �őO�ʕ\��"

$menu_t.Add_Click({

	switch($box["chk_topmost"]){ # �g�O��

	'True'{		$script:box["chk_topmost"]= Top_most "False";	break;
	}'False'{	$script:box["chk_topmost"]= Top_most "True"
	}
	} #sw
})

$menu_sr= New-Object System.Windows.Forms.ToolStripSeparator
$menu_r=  New-Object System.Windows.Forms.ToolStripMenuItem
# $menu_r.Text= "v �������X�^�[�g"

$menu_r.Add_Click({

	switch($box["chk_auto"]){ # �g�O��

	'True'{		$script:box["chk_auto"]= Auto_start "False";	break;
	}'False'{	$script:box["chk_auto"]= Auto_start "True"
	}
	} #sw
})

  
$menu_f.DropDownItems.AddRange(@($menu_e,$menu_sd,$menu_d,$menu_sn,$menu_n)) 
$menu_o.DropDownItems.AddRange(@($menu_a,$menu_sr,$menu_r,$menu_st,$menu_t))
$mnu.Items.AddRange(@($menu_f,$menu_o))

$frm.Controls.AddRange(@($mnu,$pic_box,$wait_lbl,$wait_btn,$err_box,$csl_box))

$frm.AcceptButton= $wait_btn	# [Enter]
  
# FileSystemWatcher ------ 

$wait= New-Object System.IO.FileSystemWatcher
$wait.SynchronizingObject= $frm


# $wait.InternalBufferSize= 8192 # [4096-8192-65535]
# $wait.IncludeSubdirectories= $False


$wait.NotifyFilter= [IO.NotifyFilters]::LastWrite


$wait.Add_Changed({	# event func����q�͈�i�����z..

 try{
	$script:lated_time= (Get-Item $_.FullPath).LastWriteTime.ToString('yy/MM/dd HH:mm:ss')

	# [ $_ if ok. can't switch ]
	if($lated_time -ne $chk_time){ # ��d�Ǎ��݂̕s���΍�

		$script:chk_time= $lated_time


		# $_ | write-host  # [= FileSystemEventArgs�N���X]

		Write-Host ('Updated: '+ $_.ChangeType)
		Write-Host ''

		Play_nsf $_.FullPath # $err_box.Text
		Watches_nsf ('< Watches: '+ $_.Name)

		# sleep -m 120	# �E�F�C�g�s�v
	}

 }catch{
	echo $_.exception
    	Write-Host '"ERROR: Safety Stopper >> FileSystemWatcher"'
 }
})
 
# ------ main 

 try{

 # �L���X�g

 if((Test-Path '.\mml_watch.xml') -eq $True){

	$wth_xml= [xml](cat '.\mml_watch.xml')
 }else{
	$wth_xml= [xml]$xml_watch
 }


 # �A�z�z��

 $val= @{}; $box= @{};

 Wthxml_read $script:wth_xml.table



 # ��ԃ`�F�b�N
 Top_most $box["chk_topmost"] > $null # �őO��
 Auto_start $box["chk_auto"] > $null # �����X�^�[�g


 [array]$chk_stus= Status_cheker

 [string]$lated_time= ""
 [string]$chk_time= ""

 [bool]$chk_mml= Wait_setpath $chk_stus # $wait.Filter




 # $wait_btn canceller
 if($chk_mml -eq $True){

	Toggle_sw 0 "true"
 }else{
	Toggle_sw 0 "false"
 }

 [string]$scroll_text= "" # $csl_box


 $frm.ShowDialog() > $null

 # | Out-Null -> > $null # cancel�W���o�͗}��

 Write-Host ("`r`n"+"`"mml watch`"���I�����܂�"+"`r`n")

 }catch{
	echo $_.exception
	Write-Host '"ERROR: Safety Stopper >> $frm.ShowDialog()"'

 }finally{
	$tray.Dispose() # �K�v
	$wait.Dispose()
 }
 
